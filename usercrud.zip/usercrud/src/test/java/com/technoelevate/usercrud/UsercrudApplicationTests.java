package com.technoelevate.usercrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsercrudApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.technoelevate.usercrud.repository;

import org.springframework.stereotype.Repository;

import com.technoelevate.usercrud.model.Employee;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface EmployeeRespository extends JpaRepository<Employee, Integer> {

}

package com.technoelevate.usercrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.usercrud.model.Employee;
import com.technoelevate.usercrud.service.EmployeeService;
@RestController
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
//@RequestMapping("/crud")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/users")
    public List<Employee> getAllEmployees() {
        return employeeService.getEmployees();
    }
	
	@GetMapping("/users/{id}")
	public Employee getEmployee(@PathVariable String id) {
		return employeeService.getEmployee(Integer.parseInt(id));
	}
	
	@PostMapping("/users")
	public Employee addEmployee(@RequestBody Employee employee) {
		return this.employeeService.addEmployee(employee);
	}
	
	@PutMapping("/users/{id}")
	public Employee updateEmployee(@RequestBody Employee employee) {
		return this.employeeService.updateEmployee(employee);
	}
	
	@DeleteMapping("/users/{id}")
	public String deleteEmployee(@PathVariable String id) {
		return employeeService.deleteEmployee(Integer.parseInt(id));
	}
	

}
